public abstract class Figura { 

	protected int alt;
	
	abstract double area(); // da implementare nelle classi concrete
	
	public double volume(){
		return alt*area();
	}
	
	public void stampaArea() { 
		System.out.println("Area figura:"+area()); 
	}
	
	public void stampaVolume() {
		System.out.println("Volume figura:"+volume()); 
	}
	
}
