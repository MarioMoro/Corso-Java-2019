public class Parallelepipedo extends Figura { 
	private int lato;

	// costruttori
	Parallelepipedo() {
		lato=0;
		alt=0;
	}
	
	Parallelepipedo(int l,int h) {
		lato=l;
		alt=h;
	} 

	public double area() {
		return lato*lato;
	} 
}