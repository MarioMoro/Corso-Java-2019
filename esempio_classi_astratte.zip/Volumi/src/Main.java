/**
Classi astratte in Java

Esempio no.1 
Un programma che sia in grado di valutare il volume di oggetti tridimensionali come cilindri
e parallelepipedi basandosi sul valore della loro area e dell'altezza.
Delegare i metodi comuni, come il calcolo e la stampa del volume ad una classe astratta.
*/

public class Main {
	
	public static void main (String [] args) {
		Cilindro c = new Cilindro(3,15);
		System.out.println("Cilindro:");
		c.stampaArea();
		c.stampaVolume();
		
		Parallelepipedo p = new Parallelepipedo(8, 7);
		System.out.println("Parallelepipedo:");
		p.stampaArea();
		p.stampaVolume();
		}

}
