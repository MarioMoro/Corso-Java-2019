public class Cilindro extends Figura { 
	private int raggio;
	
	// costruttori
	
	Cilindro(){
		raggio=0;
		alt=0;}
	
	Cilindro(int r,int h) {
		raggio=r;
		alt=h;}
	
	// implementa Figura.area()
	public double area() {
		return raggio*raggio*Math.PI;
	} 
}

