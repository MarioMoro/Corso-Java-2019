class Cubo implements Ritorno { 
	public void ritorno(int p) { 
		System.out.println("Il cubo di "+p+" e': " + (p*p*p)); 
	} 
}