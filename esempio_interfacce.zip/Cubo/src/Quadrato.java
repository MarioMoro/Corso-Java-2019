class Quadrato implements Ritorno { 
	public void ritorno(int p) { 
		System.out.println("Il quadrato di "+ p+" e': " + p*p); 
	} 
}
