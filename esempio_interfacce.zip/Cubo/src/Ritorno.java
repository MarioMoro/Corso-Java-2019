interface Ritorno { 
	void ritorno(int par); 
}