class Numero implements Ritorno { 
	public void ritorno(int p) { 
		System.out.println("Il numero e': " + p); 
	} 
}
