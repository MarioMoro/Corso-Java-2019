/**
Esempio no. 2 
Un programma che dato un numero intero in ingresso restituisca un oggetto rappresentativo
del quadrato del numero dato e un oggetto rappresentativo del cubo del numero assegnato.

Viene implementato il tutto attraverso l'uso di una interfaccia comune, che possa evidenziare
il comportamento del polimorfismo.

Realizzando l'interfaccia Ritorno che contiene il metodo ritorno(int par) comune a tre tipologie
di oggetti istanziati, si nota, infatti come tale chiamata sia polimorfa.
Il primo tipo corrisponde alla classe Numero, che semplicemente ritorna il valore che riceve in ingresso.
Le classi Quadrato e Cubo, attraverso lo stesso metodo ritorno(int par), restituiscono invece il quadrato
e il cubo del numero in ingresso.
*/

class Main { 
	public static void main(String args[]) { 
		Ritorno r = new Numero(); // utilizzazione del tipo interfaccia
		Quadrato q = new Quadrato(); 
		Cubo c = new Cubo();
		
		r.ritorno(2); //r è un Numero
		
		r=q; //r diventa un Quadrato
		r.ritorno(2);
		
		r=c; // r diventa un Cubo
		r.ritorno(2); 
	}
}