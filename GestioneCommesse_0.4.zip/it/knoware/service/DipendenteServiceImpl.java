package it.knoware.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import it.knoware.dao.DipendenteDao;
import it.knoware.model.Dipendente;

@Service
@Transactional
public class DipendenteServiceImpl implements DipendenteService {
	@Autowired
	private DipendenteDao dipendenteDao;

	//@Override
	@Transactional
	public void addDipendente(Dipendente dipendente) {
		dipendenteDao.addDipendente(dipendente);
	}

	//@Override
	@Transactional
	public List<Dipendente> getAllDipendenti() {
		return dipendenteDao.getAllDipendenti();
	}

	//@Override
	@Transactional
	public void deleteDipendente(Integer dipendenteId) {
		dipendenteDao.deleteDipendente(dipendenteId);
	}

	public Dipendente getDipendente(int dipendenteId) {
		return dipendenteDao.getDipendente(dipendenteId);
	}

	public Dipendente updateDipendente(Dipendente dipendente) {
		return dipendenteDao.updateDipendente(dipendente);
	}

	public void setDipendenteDao(DipendenteDao dipendenteDao) {
		this.dipendenteDao = dipendenteDao;
	}
}
