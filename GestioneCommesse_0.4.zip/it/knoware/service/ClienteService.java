package it.knoware.service;

import java.util.List;
 
import it.knoware.model.Cliente;

public interface ClienteService {
	     
	    public void addCliente(Cliente cliente);
	 
	    public List<Cliente> getAllClienti();
	 
	    public void deleteCliente(Integer clienteId);
	 
	    public Cliente getCliente(int clienteId);
	 
	    public Cliente updateCliente(Cliente cliente);
	}
