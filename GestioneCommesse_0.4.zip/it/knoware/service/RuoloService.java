package it.knoware.service;

import java.util.List;
 
import it.knoware.model.Ruolo;

public interface RuoloService {
	     
	    public void addRuolo(Ruolo ruolo);
	 
	    public List<Ruolo> getAllRuoli();
	 
	    public void deleteRuolo(Integer ruoloId);
	 
	    public Ruolo getRuolo(int ruoloId);
	 
	    public Ruolo updateRuolo(Ruolo ruolo);
	}
