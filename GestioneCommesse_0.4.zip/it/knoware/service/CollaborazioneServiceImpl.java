package it.knoware.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import it.knoware.dao.CollaborazioneDao;
import it.knoware.model.Collaborazione;

@Service
@Transactional
public class CollaborazioneServiceImpl implements CollaborazioneService {

	@Autowired
	private CollaborazioneDao collaborazioneDao;

	//@Override
	@Transactional
	public boolean addCollaborazione(Collaborazione collaborazione) {
		return collaborazioneDao.addCollaborazione(collaborazione);
	}

	//@Override
	@Transactional
	public List<Collaborazione> getAllCollaborazioni() {
		return collaborazioneDao.getAllCollaborazioni();
	}

	//@Override
	@Transactional
	public void deleteCollaborazione(Integer collaborazioneId) {
		collaborazioneDao.deleteCollaborazione(collaborazioneId);
	}

	public Collaborazione getCollaborazione(int collaborazioneId) {
		return collaborazioneDao.getCollaborazione(collaborazioneId);
	}

	public Collaborazione updateCollaborazione(Collaborazione collaborazione) {
		return collaborazioneDao.updateCollaborazione(collaborazione);
	}

	public void setCollaborazioneDao(CollaborazioneDao collaborazioneDao) {
		this.collaborazioneDao = collaborazioneDao;
	}
}
