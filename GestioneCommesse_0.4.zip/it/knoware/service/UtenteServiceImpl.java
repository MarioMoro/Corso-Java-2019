package it.knoware.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import it.knoware.dao.UtenteDao;
import it.knoware.model.Utente;

@Service
@Transactional
public class UtenteServiceImpl implements UtenteService {

	@Autowired
	private UtenteDao utenteDao;

	//@Override
	@Transactional
	public void addUtente(Utente utente) {
		utenteDao.addUtente(utente);
	}

	//@Override
	@Transactional
	public List<Utente> getAllUtenti() {
		return utenteDao.getAllUtenti();
	}

	//@Override
	@Transactional
	public void deleteUtente(Integer utenteId) {
		utenteDao.deleteUtente(utenteId);
	}

	public Utente getUtente(int utenteId) {
		return utenteDao.getUtente(utenteId);
	}
	

	public Utente updateUtente(Utente utente) {
		return utenteDao.updateUtente(utente);
	}

	public void setUtenteDao(UtenteDao utenteDao) {
		this.utenteDao = utenteDao;
	}
}
