package it.knoware.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import it.knoware.dao.ClienteDao;
import it.knoware.model.Cliente;

@Service
@Transactional
public class ClienteServiceImpl implements ClienteService {

	@Autowired
	private ClienteDao clienteDao;

	//@Override
	@Transactional
	public void addCliente(Cliente cliente) {
		clienteDao.addCliente(cliente);
	}

	//@Override
	@Transactional
	public List<Cliente> getAllClienti() {
		return clienteDao.getAllClienti();
	}

	//@Override
	@Transactional
	public void deleteCliente(Integer clienteId) {
		clienteDao.deleteCliente(clienteId);
	}

	public Cliente getCliente(int clienteId) {
		return clienteDao.getCliente(clienteId);
	}

	public Cliente updateCliente(Cliente cliente) {
		return clienteDao.updateCliente(cliente);
	}

	public void setClienteDao(ClienteDao clienteDao) {
		this.clienteDao = clienteDao;
	}
}
