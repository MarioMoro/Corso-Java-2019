package it.knoware.service;

import java.util.List;
 
import it.knoware.model.Utente;

public interface UtenteService {
	     
	    public void addUtente(Utente utente);
	 
	    public List<Utente> getAllUtenti();
	 
	    public void deleteUtente(Integer utenteId);
	 
	    public Utente getUtente(int utenteId);
	 
	    public Utente updateUtente(Utente utente);
	}
