package it.knoware.service;

import java.util.List;

public interface Service<T> {
	     
	    public void addObject(T t);
	 
	    public List<T> getAllObjects();
	 
	    public void deleteObject(Integer objectId);
	 
	    public T getObject(Integer objectId);
	 
	    public T updateObject(T t);
	}
