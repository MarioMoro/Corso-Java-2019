package it.knoware.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import it.knoware.dao.RuoloDao;
import it.knoware.model.Ruolo;

@Service
@Transactional
public class RuoloServiceImpl implements RuoloService {

	@Autowired
	private RuoloDao ruoloDao;

	//@Override
	@Transactional
	public void addRuolo(Ruolo ruolo) {
		ruoloDao.addRuolo(ruolo);
	}

	//@Override
	@Transactional
	public List<Ruolo> getAllRuoli() {
		return ruoloDao.getAllRuoli();
	}

	//@Override
	@Transactional
	public void deleteRuolo(Integer ruoloId) {
		ruoloDao.deleteRuolo(ruoloId);
	}

	public Ruolo getRuolo(int ruoloId) {
		return ruoloDao.getRuolo(ruoloId);
	}

	public Ruolo updateRuolo(Ruolo ruolo) {
		return ruoloDao.updateRuolo(ruolo);
	}

	public void setRuoloDao(RuoloDao ruoloDao) {
		this.ruoloDao = ruoloDao;
	}
}
