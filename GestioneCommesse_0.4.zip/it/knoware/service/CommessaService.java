package it.knoware.service;

import java.util.List;
 
import it.knoware.model.Commessa;

public interface CommessaService {
	     
	    public void addCommessa(Commessa commessa);
	 
	    public List<Commessa> getAllCommesse();
	 
	    public void deleteCommessa(Integer commessaId);
	 
	    public Commessa getCommessa(int commessaId);
	 
	    public Commessa updateCommessa(Commessa commessa);
	}
