package it.knoware.service;

import java.util.List;
 
import it.knoware.model.Collaborazione;

public interface CollaborazioneService {
	     
	    public boolean addCollaborazione(Collaborazione collaborazione);
	 
	    public List<Collaborazione> getAllCollaborazioni();
	 
	    public void deleteCollaborazione(Integer collaborazioneId);
	 
	    public Collaborazione getCollaborazione(int collaborazioneId);
	 
	    public Collaborazione updateCollaborazione(Collaborazione collaborazione);
	}
