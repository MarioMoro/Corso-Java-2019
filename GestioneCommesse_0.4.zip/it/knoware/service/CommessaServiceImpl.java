package it.knoware.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import it.knoware.dao.CommessaDao;
import it.knoware.model.Commessa;

@Service
@Transactional
public class CommessaServiceImpl implements CommessaService {

	@Autowired
	private CommessaDao commessaDao;

	//@Override
	@Transactional
	public void addCommessa(Commessa commessa) {
		commessaDao.addCommessa(commessa);
	}

	//@Override
	@Transactional
	public List<Commessa> getAllCommesse() {
		return commessaDao.getAllCommesse();
	}

	//@Override
	@Transactional
	public void deleteCommessa(Integer commessaId) {
		commessaDao.deleteCommessa(commessaId);
	}

	public Commessa getCommessa(int commessaId) {
		return commessaDao.getCommessa(commessaId);
	}

	public Commessa updateCommessa(Commessa commessa) {
		return commessaDao.updateCommessa(commessa);
	}

	public void setCommessaDao(CommessaDao commessaDao) {
		this.commessaDao = commessaDao;
	}
}