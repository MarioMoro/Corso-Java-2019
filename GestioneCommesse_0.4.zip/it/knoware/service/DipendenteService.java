package it.knoware.service;

import java.util.List;

import it.knoware.model.Dipendente;


public interface DipendenteService {


	public void addDipendente(Dipendente dipendente);

	public List<Dipendente> getAllDipendenti();

	public void deleteDipendente(Integer dipendenteId);

	public Dipendente getDipendente(int dipendenteId);

	public Dipendente updateDipendente(Dipendente dipendente);
}



