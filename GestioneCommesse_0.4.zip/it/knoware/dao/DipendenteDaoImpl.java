package it.knoware.dao;

import java.util.List;

import org.hibernate.SessionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import it.knoware.model.Dipendente;

@Repository
public class DipendenteDaoImpl implements DipendenteDao{

	@Autowired
	private SessionFactory sessionFactory;


	public void addDipendente(Dipendente dipendente) {
		sessionFactory.getCurrentSession().saveOrUpdate(dipendente);
	}


	@SuppressWarnings("unchecked")
	public List<Dipendente> getAllDipendenti() {
		return sessionFactory.getCurrentSession().createQuery("from Dipendente").list();
	}


	//@Override
	public void deleteDipendente(Integer dipendenteId) {
		Dipendente dipendente = (Dipendente) sessionFactory.getCurrentSession().load(Dipendente.class, dipendenteId);
		if (dipendente != null) {
			this.sessionFactory.getCurrentSession().delete(dipendente);
		}
	}


	public Dipendente getDipendente(int dipendenteId) {
		return (Dipendente) sessionFactory.getCurrentSession().get(Dipendente.class, dipendenteId);
	}


	//@Override
	public Dipendente updateDipendente(Dipendente dipendente) {
		sessionFactory.getCurrentSession().update(dipendente);
		return dipendente;
	}
}
