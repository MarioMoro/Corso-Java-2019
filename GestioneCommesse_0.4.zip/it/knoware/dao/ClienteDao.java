package it.knoware.dao;

import java.util.List;
import it.knoware.model.Cliente;
 
public interface ClienteDao {
 
    public void addCliente(Cliente cliente);
 
    public List<Cliente> getAllClienti();
 
    public void deleteCliente(Integer clienteId);
 
    public Cliente updateCliente(Cliente cliente);
 
    public Cliente getCliente(int clienteId);
}