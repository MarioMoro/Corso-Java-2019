package it.knoware.dao;

import java.util.List;
import it.knoware.model.Collaborazione;
 
public interface CollaborazioneDao {
 
    public boolean addCollaborazione(Collaborazione collaborazione);
 
    public List<Collaborazione> getAllCollaborazioni();
 
    public void deleteCollaborazione(Integer collaborazioneId);
 
    public Collaborazione updateCollaborazione(Collaborazione collaborazione);
 
    public Collaborazione getCollaborazione(int collaborazioneId);
}