package it.knoware.dao;

import java.util.List;
import it.knoware.model.Ruolo;
 
public interface RuoloDao {
 
    public void addRuolo(Ruolo ruolo);
 
    public List<Ruolo> getAllRuoli();
 
    public void deleteRuolo(Integer ruoloId);
 
    public Ruolo updateRuolo(Ruolo ruolo);
 
    public Ruolo getRuolo(int ruoloId);
}