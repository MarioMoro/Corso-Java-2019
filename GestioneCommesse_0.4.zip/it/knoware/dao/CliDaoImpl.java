package it.knoware.dao;

import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import it.knoware.model.Cliente;

public class CliDaoImpl implements Dao <Cliente> {
	
	@Autowired
	private SessionFactory sessionFactory;

	public void addObject(Cliente o) {
		sessionFactory.getCurrentSession().saveOrUpdate(o);
	}

	@SuppressWarnings("unchecked")
	public List<Cliente> getAllObjects() {
		return sessionFactory.getCurrentSession().createQuery("from Cliente").list();
	}

	//@Override
	public void deleteObject(Integer id) {
		Cliente cliente = (Cliente) sessionFactory.getCurrentSession().load(Cliente.class, id);
		if (cliente != null) {
			this.sessionFactory.getCurrentSession().delete(cliente);
		}
	}

	public Cliente updateObject(Cliente o) {
		sessionFactory.getCurrentSession().update(o);
		return o;
	}

	public Cliente getObject(Integer id) {
		return (Cliente) sessionFactory.getCurrentSession().get(Cliente.class, id);
	}
}