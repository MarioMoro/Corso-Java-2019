package it.knoware.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import it.knoware.model.Cliente;

@Repository
public class ClienteDaoImpl implements ClienteDao {

	@Autowired
	private SessionFactory sessionFactory;

	
	public void addCliente(Cliente cliente) {
		sessionFactory.getCurrentSession().saveOrUpdate(cliente);
	}

	
	@SuppressWarnings("unchecked")
	public List<Cliente> getAllClienti() {
		return sessionFactory.getCurrentSession().createQuery("from Cliente").list();
	}

	
	//@Override
	public void deleteCliente(Integer clienteId) {
		Cliente cliente = (Cliente) sessionFactory.getCurrentSession().load(Cliente.class, clienteId);
		if (cliente != null) {
			this.sessionFactory.getCurrentSession().delete(cliente);
		}
	}

	
	public Cliente getCliente(int clienteId) {
		return (Cliente) sessionFactory.getCurrentSession().get(Cliente.class, clienteId);
	}

	
	//@Override
	public Cliente updateCliente(Cliente cliente) {
		sessionFactory.getCurrentSession().update(cliente);
		return cliente;
	}
}
