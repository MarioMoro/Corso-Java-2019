package it.knoware.dao;

import java.util.List;
import it.knoware.model.Dipendente;

public interface DipendenteDao {
	 
	    public void addDipendente(Dipendente dipendente);
	 
	    public List<Dipendente> getAllDipendenti();
	 
	    public void deleteDipendente(Integer dipendenteId);
	 
	    public Dipendente updateDipendente(Dipendente dipendente);
	 
	    public Dipendente getDipendente(int dipendenteId);
}
