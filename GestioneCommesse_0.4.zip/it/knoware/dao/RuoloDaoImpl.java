package it.knoware.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import it.knoware.model.Ruolo;

@Repository
public class RuoloDaoImpl implements RuoloDao {

	@Autowired
	private SessionFactory sessionFactory;

	
	public void addRuolo(Ruolo ruolo) {
		sessionFactory.getCurrentSession().saveOrUpdate(ruolo);
	}

	
	@SuppressWarnings("unchecked")
	public List<Ruolo> getAllRuoli() {
		return sessionFactory.getCurrentSession().createQuery("from Ruolo").list();
	}

	
	//@Override
	public void deleteRuolo(Integer ruoloId) {
		Ruolo ruolo = (Ruolo) sessionFactory.getCurrentSession().load(Ruolo.class, ruoloId);
		if (ruolo != null) {
			this.sessionFactory.getCurrentSession().delete(ruolo);
		}
	}

	
	public Ruolo getRuolo(int ruoloId) {
		return (Ruolo) sessionFactory.getCurrentSession().get(Ruolo.class, ruoloId);
	}

	
	//@Override
	public Ruolo updateRuolo(Ruolo ruolo) {
		sessionFactory.getCurrentSession().update(ruolo);
		return ruolo;
	}
}
