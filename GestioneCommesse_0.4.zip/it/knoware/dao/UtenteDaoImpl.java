package it.knoware.dao;

import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import it.knoware.model.Utente;

@Repository
public class UtenteDaoImpl implements UtenteDao {

	@Autowired
	private SessionFactory sessionFactory;

	
	public void addUtente(Utente utente) {
		sessionFactory.getCurrentSession().saveOrUpdate(utente);
	}

	
	@SuppressWarnings("unchecked")
	public List<Utente> getAllUtenti() {
		return sessionFactory.getCurrentSession().createQuery("from Utente").list();
	}

	
	//@Override
	public void deleteUtente(Integer utenteId) {
		Utente utente = (Utente) sessionFactory.getCurrentSession().load(Utente.class, utenteId);
		if (utente != null) {
			this.sessionFactory.getCurrentSession().delete(utente);
		}
	}

	
	public Utente getUtente(int utenteId) {
		return (Utente) sessionFactory.getCurrentSession().get(Utente.class, utenteId);
	}
	
	
	//@Override
	public Utente updateUtente(Utente utente) {
		sessionFactory.getCurrentSession().update(utente);
		return utente;
	}
}
