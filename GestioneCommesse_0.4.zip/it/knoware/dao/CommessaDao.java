package it.knoware.dao;

import java.util.List;
import it.knoware.model.Commessa;
 
public interface CommessaDao {
 
    public void addCommessa(Commessa commessa);
 
    public List<Commessa> getAllCommesse();
 
    public void deleteCommessa(Integer commessaId);
 
    public Commessa updateCommessa(Commessa commessa);
 
    public Commessa getCommessa(int commessaId);
}