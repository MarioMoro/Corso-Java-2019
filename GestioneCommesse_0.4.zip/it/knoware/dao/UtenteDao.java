package it.knoware.dao;

import java.util.List;
import it.knoware.model.Utente;
 
public interface UtenteDao {
 
    public void addUtente(Utente utente);
 
    public List<Utente> getAllUtenti();
 
    public void deleteUtente(Integer utenteId);
 
    public Utente updateUtente(Utente utente);
 
    public Utente getUtente(int utenteId);
}