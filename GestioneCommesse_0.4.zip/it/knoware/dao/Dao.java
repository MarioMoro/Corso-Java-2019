package it.knoware.dao;

import java.util.List;
 
public interface Dao <T> {
 
    public void addObject(T o);
 
    public List<T> getAllObjects();
 
    public void deleteObject(Integer id);
 
    public T updateObject(T o);
 
    public T getObject(Integer id);
}