package it.knoware.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import it.knoware.model.Commessa;

@Repository
public class CommessaDaoImpl implements CommessaDao {

	@Autowired
	private SessionFactory sessionFactory;

	
	public void addCommessa(Commessa commessa) {
		sessionFactory.getCurrentSession().saveOrUpdate(commessa);
	}

	
	@SuppressWarnings("unchecked")
	public List<Commessa> getAllCommesse() {
		return sessionFactory.getCurrentSession().createQuery("from Commessa").list();
	}

	
	//@Override
	public void deleteCommessa(Integer commessaId) {
		Commessa commessa = (Commessa) sessionFactory.getCurrentSession().load(Commessa.class, commessaId);
		if (commessa != null) {
			this.sessionFactory.getCurrentSession().delete(commessa);
		}
	}

	
	public Commessa getCommessa(int commessaId) {
		return (Commessa) sessionFactory.getCurrentSession().get(Commessa.class, commessaId);
	}

	
	//@Override
	public Commessa updateCommessa(Commessa commessa) {
		sessionFactory.getCurrentSession().update(commessa);
		return commessa;
	}
}
