package it.knoware.dao;

import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import it.knoware.model.Collaborazione;

@Repository
public class CollaborazioneDaoImpl implements CollaborazioneDao {

	@Autowired
	private SessionFactory sessionFactory;


	public boolean addCollaborazione(Collaborazione collaborazione)  {
		try { sessionFactory.getCurrentSession().saveOrUpdate(collaborazione);
		return true;
		}
		// non possono esistere collaborazioni duplicate
		catch (org.hibernate.exception.ConstraintViolationException e) {
			sessionFactory.getCurrentSession().clear(); //pulisce la sessione
			System.out.println("addCollaborazione: La collaborazione è già presente.");
			return false;
		}
	}


	@SuppressWarnings("unchecked")
	public List<Collaborazione> getAllCollaborazioni() {
		return sessionFactory.getCurrentSession().createQuery("from Collaborazione").list();
	}


	//@Override
	// TODO aggiungere un tipo di ritorno booleano per  l'operazione andata a buon fine o meno
	public void deleteCollaborazione(Integer collaborazioneId) {
		Collaborazione collaborazione = (Collaborazione) sessionFactory.getCurrentSession().load(Collaborazione.class, collaborazioneId);
		if (collaborazione != null) {
			this.sessionFactory.getCurrentSession().delete(collaborazione);
		}
	}


	public Collaborazione getCollaborazione(int collaborazioneId) {
		return (Collaborazione) sessionFactory.getCurrentSession().get(Collaborazione.class, collaborazioneId);
	}


	//@Override
	// TODO cambiare il valore di ritorno in booleano
	public Collaborazione updateCollaborazione(Collaborazione collaborazione) {
		try { sessionFactory.getCurrentSession().update(collaborazione); }
		// non possono esistere collaborazioni duplicate
		catch (org.hibernate.exception.ConstraintViolationException e) {
			sessionFactory.getCurrentSession().clear(); //pulisce la sessione
			System.out.println("updateCollaborazione: La collaborazione è già presente.");
			return collaborazione;
		}
		return collaborazione;
	}
}