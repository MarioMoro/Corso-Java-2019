package it.knoware.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import it.knoware.model.Dipendente;
import it.knoware.service.DipendenteService;
import it.knoware.model.Utente;

@Controller
@SessionAttributes("utente")
public class GestioneDipendentiController {

	@Autowired
	private DipendenteService dipendenteService; // per l'accesso ai dati


	@RequestMapping(value = "/listaDipendenti")
	public ModelAndView listDipendenti(@ModelAttribute("utente") Utente utente, ModelAndView model) throws IOException {
		System.out.println(utente.toString());
		System.out.println("Ottengo i dipendenti...");
		List<Dipendente> listDipendenti = dipendenteService.getAllDipendenti(); // carica la lista dei dipendenti
		model.addObject("listDipendenti", listDipendenti); // la aggiunge al modello
		model.setViewName("listaDipendenti"); // nomina la vista home
		return model; // ritorna il modello che ora contiene la lista dei Dipendenti e mostra la vista "home"
	} //listDipendenti


	@RequestMapping(value = "/newDipendente", method = RequestMethod.GET)
	public ModelAndView newContatto(@ModelAttribute("utente") Utente utente, ModelAndView model) {
		if ((utente.isCrea() == true) && (utente.isAbilitato()==true)) {  
			Dipendente dipendenteForm = new Dipendente(); //creo un nuovo dipendente		
			System.out.println("creo un nuovo dipendente...");

			// crea la lista delle qualifiche
			Map<String,String> qualifica = new HashMap<String,String>();
			qualifica.put("Programmatore", "Programmatore");
			qualifica.put("Capo Progetto", "Capo Progetto");
			qualifica.put("Analista", "Analista");
			qualifica.put("Impiegato", "Impiegato");
			qualifica.put("Manager", "Manager");
			model.addObject("qualificaList", qualifica);
			model.addObject("FormDipendente", dipendenteForm);
			model.setViewName("dipendenteForm"); // imposta la vista su dipendenteForm
			return model; // ritorna il modello che ora contiene il nuovo dipendente e mostra la vista dipendenteForm
		}
		else {
			model.setViewName("permissionError");
			return model;
		}
	} //newContatto


	@RequestMapping(value = "/newDipendente", method = RequestMethod.POST)
	public ModelAndView saveDipendente(@ModelAttribute("FormDipendente") Dipendente dipendente, ModelMap model) {
		// Se l'id di dipendente è null allora lo crea, altrimenti lo aggiorna
		System.out.println("Dati inseriti: " + dipendente.toString());
		if (dipendente.getId() == null) { 
			dipendenteService.addDipendente(dipendente); // aggiunge un nuovo dipendente nel database
		} else {
			dipendenteService.updateDipendente(dipendente); // aggiorna un dipendente nel database
		}
		return new ModelAndView("redirect:/listaDipendenti"); //ritorna alla vista "/listaDipendenti" con un nuovo modello
	} //saveDipendente


	@RequestMapping(value = "/editDipendente", method = RequestMethod.GET)
	public ModelAndView editDipendente(@ModelAttribute("utente") Utente utente, @RequestParam(value="id") Integer dipendenteId) {
		if ((utente.isAggiorna() == true) && (utente.isAbilitato()==true)) {
			// crea la lista delle qualifiche
			Map<String,String> qualifica = new HashMap<String,String>();
			qualifica.put("Programmatore", "Programmatore");
			qualifica.put("Capo Progetto", "Capo Progetto");
			qualifica.put("Analista", "Analista");
			qualifica.put("Impiegato", "Impiegato");
			qualifica.put("Manager", "Manager");
			
			System.out.println("Modifico il dipendente Id: "+ dipendenteId.toString());
			Dipendente dipendente = dipendenteService.getDipendente(dipendenteId); // ritrovo il dipendente di id = dipendenteId
			ModelAndView model = new ModelAndView("dipendenteForm"); // imposto la view come dipendenteForm
			model.addObject("FormDipendente", dipendente); // aggiungo il dipendente con i suoi dati al modello
			model.addObject("qualificaList", qualifica);
			return model;
		}
		else {
			ModelAndView model = new ModelAndView("permissionError");
			return model;
		}
	} //editDipendente


	@RequestMapping(value = "/deleteDipendente", method = RequestMethod.GET)
	public ModelAndView delDipendente(@ModelAttribute("utente") Utente utente, @RequestParam(value="id") Integer dipendenteId, ModelMap model) {
		if ((utente.isCancella() == true) && (utente.isAbilitato()==true)) { 
			System.out.println("Elimino il dipendente Id: "+dipendenteId.toString());
			dipendenteService.deleteDipendente(dipendenteId);
			return new ModelAndView("redirect:/listaDipendenti");}
		else {
			return new ModelAndView("permissionError");
		}
	} //delDipendente

}