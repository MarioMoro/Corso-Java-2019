package it.knoware.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import it.knoware.model.Utente;
import it.knoware.service.UtenteService;

@Controller
@SessionAttributes("utente") // a partire da qui la sessione si porta appresso l'utente con i suoi permessi
public class GestioneLoginController {

	@Autowired
	private UtenteService utenteService; // per l'accesso ai dati


	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView newLogin(ModelAndView model) {
		Utente utenteForm = new Utente(); //creo un nuovo cliente		
		System.out.println("creo un nuovo utente...");
		model.addObject("FormUtente", utenteForm);
		model.setViewName("utenteForm"); // imposta la vista su utenteForm
		return model; // ritorna il modello che ora contiene il nuovo cliente e mostra la vista clienteForm
	} //newLogin


	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView Login(@ModelAttribute("utenteForm")Utente utente, ModelAndView model) {
		// Se l'id di cliente è null allora lo crea, altrimenti lo aggiorna
		System.out.println("Dati inseriti: " + utente.toString());

		List<Utente> listUtenti = utenteService.getAllUtenti();
		String username = utente.getUsername();
		String password = utente.getPassword();

		int i;
		for (i=0; i<listUtenti.size(); i++) {
			listUtenti.get(i).toString();
			if ((listUtenti.get(i).getUsername().equals(username)) &&
					(listUtenti.get(i).getPassword().equals(password)) &&
					(listUtenti.get(i).isAbilitato() == true)) {
				model.setViewName("index"); // utente trovato && abilitato
				model.addObject("utente", listUtenti.get(i)); //aggiunge l'utente trovato al modello e alla sessione
				return model;
			}
		}
		model.setViewName("loginError"); // imposta la vista errore login
		return model;
	}
}