package it.knoware.controller;

import java.io.IOException;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.ui.ModelMap;
import org.springframework.beans.factory.annotation.Autowired;
import it.knoware.model.Commessa;
import it.knoware.service.CommessaService;
import it.knoware.model.Dipendente;
import it.knoware.service.DipendenteService;
import it.knoware.model.Ruolo;
import it.knoware.service.RuoloService;
import it.knoware.model.Collaborazione;
import it.knoware.service.CollaborazioneService;

@Controller
public class GestioneCommesseController {

	// per l'accesso ai dati
	@Autowired
	private CommessaService commessaService; 
	@Autowired
	private DipendenteService dipendenteService;
	@Autowired
	private RuoloService ruoloService;
	@Autowired
	private CollaborazioneService collaborazioneService;


	//assegna una commessa ad un dipendente
	@RequestMapping(value = "/assegnaCommessa", method = RequestMethod.GET)
	public ModelAndView assegnaCommessa(
			@RequestParam(value="dipendenteId") Integer dipendenteId,
			ModelAndView model) {
		System.out.println("Ottengo le commesse...");
		List<Commessa> listCommesse = commessaService.getAllCommesse(); // carica la lista delle commesse e...
		model.addObject("listCommesse", listCommesse); // ...la aggiunge al modello
		model.addObject("dipendenteId", dipendenteId); // il dipendente a cui aggiungere la commessa
		System.out.println("dipendenteId: " + dipendenteId.toString());
		model.setViewName("assegnaCommessa"); // nomina la vista assegnaCommessa
		return model; // ritorna il modello che ora contiene la lista dei Commesse, e il dipendente da aggiungere e mostra la vista "home"
	} //assegnaCommessa

	
	//assegna un ruolo ad un dipendente
	@RequestMapping(value = "assegnaRuolo", method = RequestMethod.GET)
	public ModelAndView assegnaRuolo(@RequestParam(value="dipendenteId") Integer dipendenteId,
			@RequestParam(value="commessaId") Integer commessaId,
			ModelAndView model) {
		System.out.println("Ottengo i ruoli...");
		List<Ruolo> listRuoli = ruoloService.getAllRuoli(); // carica la lista dei ruoli e...
		model.addObject("listRuoli", listRuoli); // ...la aggiunge al modello
		model.addObject("dipendenteId", dipendenteId); // il dipendente a cui aggiungere la commessa
		System.out.println("dipendenteId: " + dipendenteId.toString());
		model.addObject("commessaId", commessaId);
		System.out.println("commessaId: " + commessaId.toString());
		model.setViewName("assegnaRuolo"); // nomina la vista assRuoli
		return model; // ritorna il modello che ora contiene la lista dei Ruoli, e il dipendente e la commessa da aggiungere e mostra la vista "assCommessa3"
	}


	@RequestMapping(value = "/assegnaCollaborazione", method = RequestMethod.GET)
	public ModelAndView assegnaCollaborazione(
			@RequestParam(value="commessaId") Integer commessaId,
			@RequestParam(value="dipendenteId") Integer dipendenteId,
			@RequestParam(value="ruoloId") Integer ruoloId,
			ModelAndView model) {
		/* model.addObject("commessaId", commessaId);
		model.addObject("dipendenteId", dipendenteId);
		model.addObject("ruoloId", ruoloId);*/
		System.out.println("assegnaCollaborazione: Aggiungo la Commessa: "+commessaId.toString()+" al Dipendente: "+dipendenteId.toString()+" con Ruolo: "+ruoloId.toString());

		// recupera la commessa, il dipendente ed il ruolo e li aggiunge al modello
		Commessa commessa = commessaService.getCommessa(commessaId);
		model.addObject("commessa", commessa);
		Dipendente dipendente = dipendenteService.getDipendente(dipendenteId);
		model.addObject("dipendente", dipendente);
		Ruolo ruolo = ruoloService.getRuolo(ruoloId);
		model.addObject("ruolo", ruolo);

		// crea una nuova collaborazione
		Collaborazione collaborazione = new Collaborazione (dipendente, ruolo, commessa); 

		//aggiunge la collaborazione alle rispettive liste
		/* dipendente.insCollaborazione(collaborazione);
		System.out.println(dipendente.toString());
		commessa.insCollaborazione(collaborazione);
		System.out.println(commessa.toString());
		ruolo.insCollaborazione(collaborazione);
		System.out.println(ruolo.toString()); */

		//aggiunge la collaborazione al database al se non è gia' presente
		if (collaborazioneService.addCollaborazione(collaborazione) == true) {
			model.setViewName("assCollaborazioneOk"); // nomina la vista assCollaborazioneOk
		}	
		else {
			model.setViewName("assCollaborazioneFail"); // nomina la vista assCollaborazioneFail
		}
		return model;
	} //assCollaborazione


	@RequestMapping(value = "/listaCommesse")
	public ModelAndView listCommesse(ModelAndView model) throws IOException {
		System.out.println("Ottengo i commesse...");
		List<Commessa> listCommesse = commessaService.getAllCommesse(); // carica la lista dei commesse
		model.addObject("listCommesse", listCommesse); // la aggiunge al modello
		model.setViewName("listaCommesse"); // nomina la vista home
		return model; // ritorna il modello che ora contiene la lista dei Commesse e mostra la vista "home"
	} //listCommesse


	@RequestMapping(value = "/newCommessa", method = RequestMethod.GET)
	public ModelAndView newContatto(ModelAndView model) {
		Commessa commessaForm = new Commessa(); //creo un nuovo commessa		
		System.out.println("creo un nuovo commessa...");
		model.addObject("FormCommessa", commessaForm);
		model.setViewName("commessaForm"); // imposta la vista su commessaForm
		return model; // ritorna il modello che ora contiene il nuovo commessa e mostra la vista commessaForm
	} //newContatto


	@RequestMapping(value = "/newCommessa", method = RequestMethod.POST)
	public ModelAndView saveCommessa(@ModelAttribute("userForm")Commessa commessa, ModelMap model) {
		// Se l'id di commessa è null allora lo crea, altrimenti lo aggiorna
		System.out.println("Dati inseriti: " + commessa.toString());
		if (commessa.getId() == null) { 
			commessaService.addCommessa(commessa); // aggiunge un nuovo commessa nel database
		} else {
			commessaService.updateCommessa(commessa); // aggiorna un commessa nel database
		}
		return new ModelAndView("redirect:/listaCommesse"); //ritorna alla vista "/listaCommesse" con un nuovo modello
	} //saveCommessa


	@RequestMapping(value = "/editCommessa", method = RequestMethod.GET)
	public ModelAndView editCommessa(@RequestParam(value="id") Integer commessaId) {
		System.out.println("Elimino il commessa Id: "+ commessaId.toString());
		Commessa commessa = commessaService.getCommessa(commessaId); // ritrovo il commessa di id = commessaId
		ModelAndView model = new ModelAndView("commessaForm"); // imposto la view come commessaForm
		model.addObject("FormCommessa", commessa); // aggiungo il commessa con i suoi dati al modello
		return model; 
	} //editCommessa


	@RequestMapping(value = "/deleteCommessa", method = RequestMethod.GET)
	public ModelAndView delCommessa(@RequestParam(value="id") Integer commessaId, ModelMap model) {
		System.out.println("Elimino il commessa Id: "+commessaId.toString());
		commessaService.deleteCommessa(commessaId);
		return new ModelAndView("redirect:/listaCommesse");
	} //delCommessa
}