package it.knoware.controller;

import java.io.IOException;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.ui.ModelMap;
import org.springframework.beans.factory.annotation.Autowired;
import it.knoware.model.Ruolo;
import it.knoware.service.RuoloService;

@Controller
//@SessionAttributes("ruoloForm") // !!!!!!altrimenti non viene messo subito l'oggetto ruolo nel modello
public class GestioneRuoliController {

	@Autowired
	private RuoloService ruoloService; // per l'accesso ai dati

	@RequestMapping(value = "/listaRuoli")
	public ModelAndView listRuoli(ModelAndView model) throws IOException {
		System.out.println("Ottengo i ruoli...");
		List<Ruolo> listRuoli = ruoloService.getAllRuoli(); // carica la lista dei ruoli
		model.addObject("listRuoli", listRuoli); // la aggiunge al modello
		model.setViewName("listaRuoli"); // nomina la vista home
		return model; // ritorna il modello che ora contiene la lista dei Ruoli e mostra la vista "home"
	} //listRuoli

	//@ModelAttribute
	@RequestMapping(value = "/newRuolo", method = RequestMethod.GET)
	public ModelAndView newContatto(ModelAndView model) {
		Ruolo ruoloForm = new Ruolo(); //creo un nuovo ruolo		
		System.out.println("creo un nuovo ruolo...");
		model.addObject("FormRuolo", ruoloForm);
		model.setViewName("ruoloForm"); // imposta la vista su ruoloForm
		return model; // ritorna il modello che ora contiene il nuovo ruolo e mostra la vista ruoloForm
	} //newContatto

	@RequestMapping(value = "/newRuolo", method = RequestMethod.POST)
	public ModelAndView saveRuolo(@ModelAttribute("userForm")Ruolo ruolo, ModelMap model) {
		// Se l'id di ruolo è null allora lo crea, altrimenti lo aggiorna
		System.out.println("Dati inseriti: " + ruolo.toString());
		if (ruolo.getId() == null) { 
			ruoloService.addRuolo(ruolo); // aggiunge un nuovo ruolo nel database
		} else {
			ruoloService.updateRuolo(ruolo); // aggiorna un ruolo nel database
		}
		return new ModelAndView("redirect:/listaRuoli"); //ritorna alla vista "/listaRuoli" con un nuovo modello
	}

	@RequestMapping(value = "/editRuolo", method = RequestMethod.GET)
	public ModelAndView editRuolo(@RequestParam(value="id") Integer ruoloId) {
		System.out.println("Elimino il ruolo Id: "+ ruoloId.toString());
		Ruolo ruolo = ruoloService.getRuolo(ruoloId); // ritrovo il ruolo di id = ruoloId
		ModelAndView model = new ModelAndView("ruoloForm"); // imposto la view come ruoloForm
		model.addObject("FormRuolo", ruolo); // aggiungo il ruolo con i suoi dati al modello
		return model; 
	}

	@RequestMapping(value = "/deleteRuolo", method = RequestMethod.GET)
	public ModelAndView delRuolo(@RequestParam(value="id") Integer ruoloId, ModelMap model) {
		System.out.println("Elimino il ruolo Id: "+ruoloId.toString());
		ruoloService.deleteRuolo(ruoloId);
		return new ModelAndView("redirect:/listaRuoli");
	} //delRuolo
}