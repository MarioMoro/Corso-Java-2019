package it.knoware.controller;

import java.io.IOException;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.ui.ModelMap;
import org.springframework.beans.factory.annotation.Autowired;
import it.knoware.model.Cliente;
import it.knoware.service.ClienteService;

@Controller
//@SessionAttributes("clienteForm") // !!!!!!altrimenti non viene messo subito l'oggetto cliente nel modello
public class GestioneClientiController {
	
	@Autowired
    private ClienteService clienteService; // per l'accesso ai dati
	
	/* deve stare in un solo punto */
	/* @RequestMapping(value = "/")
	public ModelAndView menu(ModelAndView model) {
		System.out.println("menu principale");
		model.setViewName("utenteForm");
		return model;
	} //menu
*/
	// GESTIONE CLIENTI 
	@RequestMapping(value = "/listaClienti")
    public ModelAndView listClienti(ModelAndView model) throws IOException {
		System.out.println("Ottengo i clienti...");
        List<Cliente> listClienti = clienteService.getAllClienti(); // carica la lista dei clienti
        model.addObject("listClienti", listClienti); // la aggiunge al modello
        model.setViewName("listaClienti"); // nomina la vista home
        return model; // ritorna il modello che ora contiene la lista dei Clienti e mostra la vista "home"
    } //listClienti
 
	//@ModelAttribute
    @RequestMapping(value = "/newCliente", method = RequestMethod.GET)
    public ModelAndView newContatto(ModelAndView model) {
		Cliente clienteForm = new Cliente(); //creo un nuovo cliente		
		System.out.println("creo un nuovo cliente...");
	    model.addObject("FormCliente", clienteForm);
        model.setViewName("clienteForm"); // imposta la vista su clienteForm
        return model; // ritorna il modello che ora contiene il nuovo cliente e mostra la vista clienteForm
    } //newContatto
 
    @RequestMapping(value = "/newCliente", method = RequestMethod.POST)
    public ModelAndView saveCliente(@ModelAttribute("userForm")Cliente cliente, ModelMap model) {
    	// Se l'id di cliente è null allora lo crea, altrimenti lo aggiorna
    	System.out.println("Dati inseriti: " + cliente.toString());
    	if (cliente.getId() == null) { 
            clienteService.addCliente(cliente); // aggiunge un nuovo cliente nel database
        } else {
            clienteService.updateCliente(cliente); // aggiorna un cliente nel database
        }
        return new ModelAndView("redirect:/listaClienti"); //ritorna alla vista "/listaClienti" con un nuovo modello
    }
    
    @RequestMapping(value = "/editCliente", method = RequestMethod.GET)
    public ModelAndView editCliente(@RequestParam(value="id") Integer clienteId) {
    	System.out.println("Elimino il cliente Id: "+ clienteId.toString());
    	Cliente cliente = clienteService.getCliente(clienteId); // ritrovo il cliente di id = clienteId
        ModelAndView model = new ModelAndView("clienteForm"); // imposto la view come clienteForm
        model.addObject("FormCliente", cliente); // aggiungo il cliente con i suoi dati al modello
    	return model; 
    }
    
    @RequestMapping(value = "/deleteCliente", method = RequestMethod.GET)
    public ModelAndView delCliente(@RequestParam(value="id") Integer clienteId, ModelMap model) {
    	System.out.println("Elimino il cliente Id: "+clienteId.toString());
    	clienteService.deleteCliente(clienteId);
    	return new ModelAndView("redirect:/listaClienti");
    } //delCliente
}