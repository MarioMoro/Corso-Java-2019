package it.knoware.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Cliente")
public class Cliente implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@Column(name = "denominazione")
	private String denominazione;

	@Column(name = "indirizzo")
	private String indirizzo;

	@Column(name = "cap")
	private String cap;

	@Column(name = "citta")
	private String citta;

	@Column(name = "nazione")
	private String nazione;

	@Column(name = "telefono")
	private String telefono;

	@Column(name = "fax")
	private String fax;

	@Column(name = "email")
	private String email;

	@Column(name = "sito")
	private String sito;

	@Column(name = "partitaIva")
	private String partitaIva;
	
	@Column(name="abilitato")
	private boolean abilitato;

	public Cliente() {
		//costruttore vuoto
	}
	
	//id
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId() {
		return this.id;
	}

	//denominazione
	public void setDenominazione(String denominazione) {
		this.denominazione = denominazione;
	}
	
	public String getDenominazione() {
		return this.denominazione;
	}

	//indirizzo
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	public String getIndirizzo() {
		return this.indirizzo;
	}

	//cap
	public void setCap(String cap) {
		this.cap = cap;
	}
	public String getCap() {
		return this.cap;
	}

	//citta
	public void setCitta(String citta) {
		this.citta = citta;
	}
	public String getCitta() {
		return this.citta;
	}

	//nazione
	public void setNazione(String nazione) {
		this.nazione = nazione;
	}
	public String getNazione() {
		return this.nazione;
	}

	//telefono
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public String getTelefono() {
		return this.telefono;
	}

	//fax
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getFax() {
		return this.fax;
	}

	//email
	public void setEmail(String email) {
		this.email = email;
	}
	public String getEmail() {
		return this.email;
	}

	//sito
	public void setSito(String sito) {
		this.sito = sito;
	}
	public String getSito() {
		return this.sito;
	}

	//partitaIva
	public void setPartitaIva(String partitaIva) {
		this.partitaIva = partitaIva;
	}
	public String getPartitaIva() {
		return this.partitaIva;
	}
	
	//abilitato
	public boolean isAbilitato() {
		return abilitato;
	}

	public void setAbilitato(boolean abilitato) {
		this.abilitato = abilitato;
	}

	//toString
	@Override
	public String toString() {
		return "Cliente [id=" + id + ", denominazione=" + denominazione + ", indirizzo=" + indirizzo + ", cap=" + cap
				+ ", citta=" + citta + ", nazione=" + nazione + ", telefono=" + telefono + ", fax=" + fax + ", email="
				+ email + ", sito=" + sito + ", partitaIva=" + partitaIva + ", abilitato=" + abilitato + "]";
	}
}