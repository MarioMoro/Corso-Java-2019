package it.knoware.model;

import java.util.Set;
import java.util.HashSet;
import java.io.Serializable;
import javax.persistence.CascadeType;
//import javax.persistence.FetchType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Id;
//import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NaturalId;

@Entity
@Table(name = "Dipendente")
public class Dipendente implements Serializable {

	private static final long serialVersionUID = 1L;
	
	//quando viene cancellato un dipendente, cancella anche le sue collaborazioni
	@OneToMany
	(mappedBy = "dipendente",
	orphanRemoval = true,
	cascade = { CascadeType.REMOVE }, // rimozione collaborazioni associate
	targetEntity = Collaborazione.class,
	fetch = FetchType.EAGER) // altrimenti il set collaborazioni non viene prelevato
	private Set <Collaborazione> collaborazioni = new HashSet<Collaborazione>();

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Integer id;

	@NaturalId
	@Column(name = "username") // non possono esistere due user name uguali
	// TODO aggiungere il not null
	private String username;

	@Column(name = "password")
	private String password;
	
	//@Id
	@Column(name = "idSup")
	private Integer idSup;

	@Column(name = "nome")
	private String nome;

	@Column(name = "cognome")
	private String cognome;

	@Column(name = "qualifica")
	private String qualifica;

	@Column(name = "indirizzo")
	private String indirizzo;

	@Column(name = "cap")
	private String cap;

	@Column(name = "citta")
	private String citta;

	@Column(name = "telefono")
	private String telefono;

	@Column(name = "email")
	private String email;

	@Column(name = "codiceFiscale")
	private String codiceFiscale;

	@Column(name = "costoOrario")
	private float costoOrario;

	@Column(name = "abilitato")
	private boolean abilitato = true;
	
	
	//costruttore vuoto
	public Dipendente() {
		super();
	}

	//id
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId() {
		return this.id;
	}

	//qualificaSup
	public void setQualifica(String qualifica) {
		this.qualifica = qualifica;
	}
	public String getQualifica() {
		return this.qualifica;
	}

	//idSup
	public void setIdSup(Integer idSup) {
		this.idSup = idSup;
	}
	public Integer getIdSup() {
		return this.idSup;
	}

	//nome
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getNome() {
		return this.nome;
	}

	//cognome
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getCognome() {
		return this.cognome;
	}

	//indirizzo
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	public String getIndirizzo() {
		return this.indirizzo;
	}

	//cap
	public void setCap(String cap) {
		this.cap = cap;
	}
	public String getCap() {
		return this.cap;
	}

	//citta
	public void setCitta(String citta) {
		this.citta = citta;
	}
	public String getCitta() {
		return this.citta;
	}

	//telefono
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public String getTelefono() {
		return this.telefono;
	}

	//email
	public void setEmail(String email) {
		this.email = email;
	}
	public String getEmail() {
		return this.email;
	}

	//codiceFiscale
	public void setCodiceFiscale(String codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}
	public String getCodiceFiscale() {
		return this.codiceFiscale;
	}

	//costoOrario
	public void setCostoOrario(float costoOrario) {
		this.costoOrario = costoOrario;
	}
	public float getCostoOrario() {
		return this.costoOrario;
	}

	//collaborazioni
	public Set<Collaborazione> getCollaborazioni() {
		return this.collaborazioni;
	}
	public void setCollaborazioni(Set<Collaborazione> collaborazioni) {
		this.collaborazioni = collaborazioni;
	}
	
	public void insCollaborazione(Collaborazione collaborazione) {
		this.collaborazioni.add(collaborazione);
	}
	public void delCollaborazione(Collaborazione collaborazione) {
		this.collaborazioni.remove(collaborazione);
	}
	

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	//abilitato
	public boolean isAbilitato() {
		return abilitato;
	}
	public void setAbilitato(boolean abilitato) {
		this.abilitato = abilitato;
	}

	//toString
	@Override
	public String toString() {
		return "Dipendente [collaborazioni=" + collaborazioni + ", id=" + id + ", idSup=" + idSup + ", nome=" + nome
				+ ", cognome=" + cognome + ", qualifica=" + qualifica + ", indirizzo=" + indirizzo + ", cap=" + cap
				+ ", citta=" + citta + ", telefono=" + telefono + ", email=" + email + ", codiceFiscale="
				+ codiceFiscale + ", costoOrario=" + costoOrario + ", abilitato=" + abilitato + "]";
	}
} 