package it.knoware.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
//import javax.persistence.ManyToOne;
//import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "Ruolo")
public class Ruolo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	//quando viene cancellato un ruolo, cancella anche le relative collaborazioni
	@OneToMany
	(mappedBy = "ruolo",
	orphanRemoval = true,
	cascade = { CascadeType.REMOVE }, // rimozione collaborazioni associate
	targetEntity = Collaborazione.class,
	fetch = FetchType.EAGER ) //altrimenti il set collaborazioni non viene prelevato
	private Set<Collaborazione> collaborazioni = new HashSet<Collaborazione>();
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@Column(name = "descrizione")
	private String descrizione;
	
	@Column(name = "abilitato")
	private boolean abilitato = true;
	
	//Costruttore vuoto
	public Ruolo() {
		super();
	}
	
	//id
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId() {
		return this.id;
	}

	//descrizione
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	public String getDescrizione() {
		return this.descrizione;
	}
	
	//collaborazioni
	public Set<Collaborazione> getCollaborazioni() {
		return this.collaborazioni;
	}
	public void setCollaborazioni(Set<Collaborazione> collaborazioni) {
		this.collaborazioni = collaborazioni;
	}
	
	public void insCollaborazione(Collaborazione collaborazione) {
		this.collaborazioni.add(collaborazione);
	}
	
	public void delCollaborazione(Collaborazione collaborazione) {
		this.collaborazioni.remove(collaborazione);
	}
	
	//toString
	@Override
	public String toString() {
		return "Ruolo [collaborazioni=" + collaborazioni + ", id=" + id + ", descrizione=" + descrizione + "]";
	}
}