package it.knoware.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.hibernate.annotations.NaturalId;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "Utente", uniqueConstraints = @UniqueConstraint(columnNames = { "username" }))
public class Utente implements Serializable {
	private static final long serialVersionUID = 1L;

	@OneToOne(targetEntity = Dipendente.class)
	@JoinColumn(name = "dipendente_id")
	private Dipendente dipendente;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@NaturalId
	@Column(name = "username") // non possono esistere due user name uguali
	// TODO aggiungere il not null
	private String username;

	@Column(name = "password")
	private String password;
	
	@Column(name = "email")
	private String email;

	@Column(name = "crea") // se usiamo create c'è un bug in hibernate/mysql che non fa creare la tabella!!!
	private boolean crea;

	@Column(name = "leggi")
	private boolean leggi;

	@Column(name = "aggiorna")
	private boolean aggiorna;

	@Column(name = "cancella")
	private boolean cancella;
	
	@Column(name="abilitato")
	private boolean abilitato;

	public Utente() {
		//costruttore vuoto
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isCrea() {
		return crea;
	}

	public void setCrea(boolean crea) {
		this.crea = crea;
	}

	public boolean isLeggi() {
		return leggi;
	}

	public void setLeggi(boolean leggi) {
		this.leggi = leggi;
	}

	public boolean isAggiorna() {
		return aggiorna;
	}

	public void setAggiorna(boolean aggiorna) {
		this.aggiorna = aggiorna;
	}

	public boolean isCancella() {
		return cancella;
	}

	public void setCancella(boolean cancella) {
		this.cancella = cancella;
	}

	public boolean isAbilitato() {
		return abilitato;
	}

	public void setAbilitato(boolean abilitato) {
		this.abilitato = abilitato;
	}
	
	//dipendente
	public void setDipendente(Dipendente dipendente) {
		this.dipendente = dipendente;
	}
	public Dipendente getDipendente() {
		return this.dipendente;
	}

	//toString
	@Override
	public String toString() {
		return "Utente [id=" + id + ", username=" + username + ", password=" + password + ", email=" + email + ", crea="
				+ crea + ", leggi=" + leggi + ", aggiorna=" + aggiorna + ", cancella=" + cancella + ", abilitato="
				+ abilitato + "]";
	}	
}