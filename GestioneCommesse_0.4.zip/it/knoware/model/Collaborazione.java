package it.knoware.model;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.ManyToOne;
//import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.UniqueConstraint;

@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames={"dipendente_id", "ruolo_id", "commessa_id"}))
// alza un'eccezione se tentiamo di assegnare una collaborazione che è gia' presente
// org.hibernate.exception.ConstraintViolationException

public class Collaborazione {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@ManyToOne(targetEntity = Dipendente.class)
	@JoinColumn(name = "dipendente_id")
	private Dipendente dipendente;
	
	@ManyToOne(targetEntity = Ruolo.class)
	@JoinColumn(name = "ruolo_id")
	private Ruolo ruolo;
	
	@ManyToOne(targetEntity = Commessa.class)
	@JoinColumn(name = "commessa_id")
	private Commessa commessa;
	
	@Column(name = "abilitato")
	private boolean abilitato = true;

	//costruttori
	public Collaborazione() {
		super();
	}

	public Collaborazione(Dipendente dipendente, Ruolo ruolo, Commessa commessa) {
		this.dipendente = dipendente;
		this.ruolo = ruolo;
		this.commessa = commessa;
	}

	//id
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	//dipendente
	public Dipendente getDipendente() {
		return dipendente;
	}

	public void setDipendente(Dipendente dipendente) {
		this.dipendente = dipendente;
	}

	//ruolo
	public Ruolo getRuolo() {
		return ruolo;
	}

	public void setRuolo(Ruolo ruolo) {
		this.ruolo = ruolo;
	}

	//commessa
	public Commessa getCommessa() {
		return commessa;
	}

	public void setCommessa(Commessa commessa) {
		this.commessa = commessa;
	}
}
