package it.knoware.model;

import java.io.Serializable;
import java.util.Set;
import java.util.HashSet;
import javax.persistence.CascadeType;
//import javax.persistence.FetchType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
//import javax.persistence.JoinTable;
//import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "Commessa")
public class Commessa implements Serializable {
	private static final long serialVersionUID = 1L;

	//quando viene cancellata una commessa, cancella anche le collaborazioni ad essa associate
	@OneToMany
	(mappedBy = "commessa",
	orphanRemoval = true,
	cascade = { CascadeType.REMOVE }, // rimozione collaborazioni associate
	targetEntity = Collaborazione.class,
	fetch = FetchType.EAGER) // altrimenti il set collaborazioni non viene prelevato
	private Set <Collaborazione> collaborazioni = new HashSet<Collaborazione>();

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@Column(name = "descrizione")
	private String descrizione;

	//@Id
	@Column(name = "idCliente")
	private String idCliente;

	@Column(name = "guadagno")
	private String guadagno;
	
	@Column(name = "abilitato")
	private boolean abilitato = true;

	//costruttore vuoto
	public Commessa() {
	}

	//id
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId() {
		return this.id;
	}

	//descrizione
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public String getDescrizione() {
		return this.descrizione;
	}

	//indirizzo
	public void setIdCliente(String idCliente) {
		this.idCliente = idCliente;
	}
	public String getIdCliente() {
		return this.idCliente;
	}

	//guadagno
	public void setGuadagno(String guadagno) {
		this.guadagno = guadagno;
	}
	public String getGuadagno() {
		return this.guadagno;
	}

	//collaborazioni
	public Set<Collaborazione> getCollaborazioni() {
		return this.collaborazioni;
	}
	public void setCollaborazioni(Set<Collaborazione> collaborazioni) {
		this.collaborazioni = collaborazioni;
	}
	
	public void insCollaborazione(Collaborazione collaborazione) {
		this.collaborazioni.add(collaborazione);
	}
	public void delCollaborazione(Collaborazione collaborazione) {
		this.collaborazioni.remove(collaborazione);
	}

	//abilitato
	public boolean isAbilitato() {
		return abilitato;
	}
	public void setAbilitato(boolean abilitato) {
		this.abilitato = abilitato;
	}

	//toString
	@Override
	public String toString() {
		return "Commessa [collaborazioni=" + collaborazioni + ", id=" + id + ", descrizione=" + descrizione
				+ ", idCliente=" + idCliente + ", guadagno=" + guadagno + ", abilitato=" + abilitato + "]";
	}
}