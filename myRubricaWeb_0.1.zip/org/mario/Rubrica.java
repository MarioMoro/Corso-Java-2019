package org.mario;

import java.util.ArrayList;
import java.util.List;
import java.io.*;


public class Rubrica {
	
	private List<Contatto> rubrica = new ArrayList<Contatto>();
	private String nome_rubrica; 
	
	public Rubrica() {
		this.nome_rubrica="";
		
	}
	
	public List<Contatto> stampaRubrica() {
		int i;
		Contatto temp;
		System.out.println("Stampa rubrica");
		System.out.println(this.getnome_rubrica());
		
		for (i=0; i < rubrica.size(); i++) {
			temp = rubrica.get(i);
			System.out.println("Nome:" + temp.getNome());
			System.out.println("Cognome:" +  temp.getCognome());
			System.out.println("Telefono:" + temp.getTelefono());
			}
		return this.rubrica;
	}
	
	public Rubrica(String nome_rubrica) {
		this.nome_rubrica = nome_rubrica;
	}
	
	public String salvaRubrica() throws IOException {
		FileOutputStream out = new FileOutputStream(this.getnome_rubrica()+".sav");
        ObjectOutputStream s = new ObjectOutputStream(out);
        
        s.writeObject(this.rubrica);
        s.writeObject(this.nome_rubrica);
        s.close();
        System.out.println("Rubrica salvata in:" + System.getProperty("user.dir"));
        return System.getProperty("user.dir");
	}
	
	public void caricaRubrica(String nome_rubrica) throws IOException, ClassNotFoundException {
		FileInputStream in = new FileInputStream(nome_rubrica+".sav");
        ObjectInputStream s = new ObjectInputStream(in);
        
        this.rubrica = (List<Contatto>) s.readObject();
        this.nome_rubrica = (String) s.readObject();
        s.close();
	}
	
	public void setnome_rubrica(String nome_rubrica) {
		this.nome_rubrica = nome_rubrica;
	}
	
	public String getnome_rubrica() {
		return this.nome_rubrica;
	}
	
	public List<Contatto> get_listaContatti() {
		return this.rubrica;
		
	}
		public void setContatto(Contatto contatto) {
		rubrica.add(contatto);
	}
	
	public Contatto getContatto(String nome, String cognome) {
		int i;
		Contatto temp;
		
		temp = rubrica.get(0);
		for (i=0; i < rubrica.size(); i++) {
			temp = rubrica.get(i);
			if ( (nome.equals(temp.getNome())) && (cognome.equals(temp.getCognome())) ) {
				return temp; // contatto trovato
			}
		}
		return null; // contatto non trovato
	}
	
	public boolean delContatto(String nome, String cognome) {
		int i;
		Contatto temp;
		for (i=0; i < rubrica.size(); i++) {
			temp = rubrica.get(i);
			if ( (nome.equals(temp.getNome())) && (cognome.equals(temp.getCognome())) ) {
				rubrica.remove(i); // contatto trovato e rimosso
				return true;
				// System.out.println("rimosso");
			}
		}
		return false;
	}

}
