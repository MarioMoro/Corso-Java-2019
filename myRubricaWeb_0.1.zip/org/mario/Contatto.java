package org.mario;

import java.io.Serializable;

/**
 * Classe Contatto Telefonico
 *
 */
public class Contatto implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private String nome;
	private String cognome;
	private String telefono;
	
    public Contatto(String nome, String cognome, String telefono)
    {
      this.nome = nome;
      this.cognome = cognome;
      this.telefono = telefono;
    }
    
    public Contatto() {
		// TODO Auto-generated constructor stub
	}

	public String getNome() {
    	return this.nome;
    }
    
    public void setNome(String nome) {
    	this.nome = nome;
    }
    
    public String getCognome() {
    	return this.cognome;
    }
    
    public void setCognome(String cognome) {
    	this.cognome = cognome;
    }
    
    public String getTelefono() {
    	return this.telefono;
    }
    
    public void setTelefono(String telefono) {
    	this.telefono = telefono;
    }
    
    public void stampaContatto() {
    	System.out.println("Nome: "+getNome());
    	System.out.println("Cognome: "+getCognome());
    	System.out.println("Telefono: "+getTelefono());
    }
}
