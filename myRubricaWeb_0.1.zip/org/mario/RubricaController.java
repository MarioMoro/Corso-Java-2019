package org.mario;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;


import org.springframework.ui.ModelMap;

@Controller
@SessionAttributes("Rubrica") // !!!!!!altrimenti non viene messo subito l'oggetto rubrica nel modello

public class RubricaController {

	// istanzia la rubrica appena entra nell'app e crea il modello di default command. Ritorna alla vista addRubrica
	@RequestMapping(value = "/Rubrica")
	public ModelAndView Rubrica() {
		return new ModelAndView("Rubrica", "Rubrica", new Rubrica());
	}

	// addRubrica vista fittizia che sta nel form Rubrica action
	@RequestMapping(value = "/addRubrica", method = RequestMethod.POST)
	
	public String addRubrica(@ModelAttribute("Rubrica")Rubrica rubrica,  ModelMap model) throws IOException {

		model.addAttribute("nomerubrica", rubrica.getnome_rubrica()+".sav");
		model.addAttribute("dir_sav", rubrica.salvaRubrica());

		//System.out.println(rubrica.getNome_Rubrica()); // aggiunge al modello il nome_rubrica
		return "result";
	}

	// istanzia la rubrica appena entra nell'app e crea il modello di default command. Ritorna alla vista addRubrica
	@RequestMapping(value = "/Contatto", method = RequestMethod.GET)
	public String Contatto(ModelMap model) {
		model.addAttribute("Contatto", new Contatto());
		System.out.println("Contatto istanziato...");
		return "Contatto";
	}

	@RequestMapping(value = "/addContatto", method = RequestMethod.POST)
	public String addContatto(@ModelAttribute("Contatto")Contatto contatto, @ModelAttribute("Rubrica")Rubrica rubrica, ModelMap model) {
		model.addAttribute("nome", contatto.getNome());
		model.addAttribute("cognome", contatto.getCognome());
		model.addAttribute("telefono", contatto.getTelefono());
		rubrica.setContatto(contatto);
        System.out.println("Contatto creato in..." + rubrica.getnome_rubrica());
        rubrica.stampaRubrica();
		return "result_ins";
	} 
	
	// istanzia la rubrica appena entra nell'app e crea il modello di default command. Ritorna alla vista addRubrica
	@RequestMapping(value = "/StampaRubrica", method = RequestMethod.GET)
	public String StampaRubrica(@ModelAttribute("Rubrica") Rubrica rubrica, ModelMap model) {
		//System.out.println("####");
		List<Contatto> listaContatti = rubrica.get_listaContatti();
		List<String> listaContattiString = new ArrayList<String>();
		int i;
		Contatto temp;
		String contTemp;
		
		for (i=0; i < listaContatti.size(); i++) {
			temp = listaContatti.get(i);
			contTemp = temp.getNome()+", " +  temp.getCognome()+ ", " + temp.getTelefono();
			listaContattiString.add(contTemp);
		}
		model.addAttribute("listaContatti", listaContattiString);
		
		//rubrica.stampaRubrica();
		return "stampa_rubrica";
	}
	
	@RequestMapping(value = "/SalvaRubrica", method = RequestMethod.GET)
	public String SalvaRubrica(@ModelAttribute("Rubrica") Rubrica rubrica, ModelMap model) throws IOException {
		System.out.println("Salvataggio rubrica..." +rubrica.getnome_rubrica()+".sav");
		//System.out.println(rubrica.getNome_Rubrica()); // aggiunge al modello il nome_rubrica
		//rubrica.salvaRubrica();
		model.addAttribute("nomerubrica", rubrica.getnome_rubrica()+".sav");
		model.addAttribute("dir_sav", rubrica.salvaRubrica());
		return "result";	
	}
	
	// prima istanzia una nuova rubrica vuota, poi carica i valori
	@RequestMapping(value = "/CaricaRubrica")
	public ModelAndView CaricaRubrica() {
		return new ModelAndView("CaricaRubrica", "Rubrica", new Rubrica());
	}
	
	@RequestMapping(value = "/loadRubrica", method = RequestMethod.POST)
	public String CaricaRubrica(@ModelAttribute("Rubrica")Rubrica rubrica,  ModelMap model) throws IOException, ClassNotFoundException {
		
		// carico la rubrica istanziata con i dati del nome inserito
		model.addAttribute("nomerubrica", rubrica.getnome_rubrica()+".sav");
		rubrica.caricaRubrica(rubrica.getnome_rubrica());
		//model.addAttribute("dir_sav", rubrica.salvaRubrica());
		
		return "rubrica_caricata";	
	}
	
	@RequestMapping(value = "/RicContatto", method = RequestMethod.GET)
	public ModelAndView RicContatto(@ModelAttribute("Rubrica")Rubrica rubrica, ModelMap model) {
		return new ModelAndView("RicContatto", "Contatto", new Contatto());
	}
	
	@RequestMapping(value = "/searchContatto", method = RequestMethod.POST)
	public String searchContatto(@ModelAttribute("Rubrica")Rubrica rubrica, @ModelAttribute("Contatto")Contatto contatto, ModelMap model) {
		// ha solo nome e cognome
		contatto = rubrica.getContatto(contatto.getNome(), contatto.getCognome());
		if (contatto == null) return "contatto_non_trovato";
		else {
			// trovato il contatto ho tutti i dati
			model.addAttribute("nome", contatto.getNome());
			model.addAttribute("cognome", contatto.getCognome());
			model.addAttribute("telefono", contatto.getTelefono());
		    return "contatto_trovato"; }	
	}
	
	@RequestMapping(value = "/CanContatto", method = RequestMethod.GET)
	public ModelAndView CanContatto(@ModelAttribute("Rubrica")Rubrica rubrica, ModelMap model) {
		return new ModelAndView("CanContatto", "Contatto", new Contatto());
	}
	
	@RequestMapping(value = "/delContatto", method = RequestMethod.POST)
	public String delContatto(@ModelAttribute("Rubrica")Rubrica rubrica, @ModelAttribute("Contatto")Contatto contatto, ModelMap model) {
		// ha solo nome e cognome
		boolean cancellato;
		
		cancellato = rubrica.delContatto(contatto.getNome(), contatto.getCognome());
		// per la visualizzazione 
		model.addAttribute("nome", contatto.getNome());
		model.addAttribute("cognome", contatto.getCognome());
		
		if (cancellato == false) return "contatto_non_trovato";
		else {
			// trovato il contatto ho tutti i dati
		    return "contatto_cancellato"; }	
	}
	
	
}